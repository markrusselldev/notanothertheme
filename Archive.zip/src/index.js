
import '@shoelace-style/shoelace/dist/themes/light.css';
import '@shoelace-style/shoelace/dist/components/button/button.js';
import 'open-props/style';
import './init.js';
import './styles/tokens.css'
import './styles/header.css';
import './styles/footer.css';
