export default {
  plugins: {
    'postcss-preset-env': { stage: 1, autoprefixer: true }
  }
};